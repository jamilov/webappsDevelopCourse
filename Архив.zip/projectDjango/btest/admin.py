from django.contrib import admin
from .models import Bb
from .models import Client
from .models import Order



admin.site.register(Bb)
admin.site.register(Client)
admin.site.register(Order)
